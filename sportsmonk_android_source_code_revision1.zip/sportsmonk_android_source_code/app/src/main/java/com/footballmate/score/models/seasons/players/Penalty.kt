package com.footballmate.score.models.seasons.players


class Penalty(
        val won: Int? = null,
        val scores: Int? = null,
        val missed: Int? = null,
        val committed: Int? = null,
        val saves: Int? = null
)