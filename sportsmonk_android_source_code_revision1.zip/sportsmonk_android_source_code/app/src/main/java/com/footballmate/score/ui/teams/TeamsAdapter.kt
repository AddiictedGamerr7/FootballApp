package com.footballmate.score.ui.teams

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.footballmate.score.R
import com.footballmate.score.models.team.Team
import com.footballmate.score.ui.fixture.MatchDetailActivity
import com.footballmate.score.utils.AdmobAdsUtil
import com.squareup.picasso.Picasso
import kotlinx.android.synthetic.main.include_ads_layout.view.*
import kotlinx.android.synthetic.main.team_row_item.view.*


class TeamsAdapter(private val teams: List<Team>, private val context: Context) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {


    private val typeAdvert = 1
    private val typeGame = 2
    override fun onCreateViewHolder(parent: ViewGroup, position: Int): RecyclerView.ViewHolder {
        return when (position) {
            typeGame -> LiveGameViewHolder(LayoutInflater.from(parent.context!!).inflate(R.layout.team_row_item, parent, false))
            typeAdvert -> SmallAdvertViewHolder(LayoutInflater.from(parent.context!!).inflate(R.layout.include_ads_layout, parent, false))
            else -> LiveGameViewHolder(LayoutInflater.from(parent.context!!).inflate(R.layout.team_row_item, parent, false))
        }
    }

    override fun getItemCount() = teams.size

    override fun getItemViewType(position: Int): Int {
        return if (position == 5) {
            typeAdvert
        } else {
            typeGame
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        if (holder is LiveGameViewHolder) {
            holder.bindData(position)
        } else {
            val gameViewHolder = holder as SmallAdvertViewHolder
            gameViewHolder.bindData()
            gameViewHolder.setIsRecyclable(false)
        }
    }

    inner class LiveGameViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

        fun bindData(position: Int) {
            val team = teams[position]

            Picasso.get().load(team.logo_path).into(itemView.teamFlag)
            itemView.teamName.text = team.name
            itemView.position.text = (position + 1).toString()

            itemView.teamLayout.setOnClickListener {
                val intent = Intent(context, MatchDetailActivity::class.java)
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                intent.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY)
                intent.putExtra("team", team)
                context.startActivity(intent)
            }

        }
    }

    inner class SmallAdvertViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        fun bindData() {
            AdmobAdsUtil.loadBannerAds(context, itemView.advertLayout)
        }
    }
}