package com.footballmate.score.models.fixture.goals

import java.io.Serializable

class GoalData(var data: ArrayList<Goal>): Serializable