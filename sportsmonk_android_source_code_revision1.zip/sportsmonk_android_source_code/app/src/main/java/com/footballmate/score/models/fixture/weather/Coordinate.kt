package com.footballmate.score.models.fixture.weather

import java.io.Serializable

class Coordinate(
        val lat: Double,
        val lon: Double
) : Serializable