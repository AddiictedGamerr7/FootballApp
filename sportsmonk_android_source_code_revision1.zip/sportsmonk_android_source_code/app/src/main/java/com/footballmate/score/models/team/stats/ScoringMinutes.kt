package com.footballmate.score.models.team.stats


class ScoringMinutes(
        val minute: String,
        val count: String,
        val percentage: String
)