package com.footballmate.score.api.callbacks

import com.footballmate.score.models.fixture.Fixture

class H2HCallback(var firstTeam_VS_secondTeam: ArrayList<Fixture>, var firstTeam_lastResults: ArrayList<Fixture>, var secondTeam_lastResults: ArrayList<Fixture>)