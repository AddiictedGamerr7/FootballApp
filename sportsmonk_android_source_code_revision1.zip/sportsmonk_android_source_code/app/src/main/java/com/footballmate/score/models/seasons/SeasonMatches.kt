package com.footballmate.score.models.seasons

import com.footballmate.score.api.callbacks.MatchesCallback
import com.footballmate.score.models.fixture.round.RoundData


class SeasonMatches(
        val id: Long,
        val name: Boolean,
        val league_id: Long,
        val is_current_season: Boolean,
        val current_round_id: Long,
        val current_stage_id: Long,
        val results: MatchesCallback,
        val round: RoundData,
        val upcoming: MatchesCallback
)