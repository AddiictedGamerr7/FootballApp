package com.footballmate.score.api.callbacks

import com.footballmate.score.models.News


class NewsCallback(var articles: ArrayList<News>)