package com.footballmate.score.models.seasons.topscorers

import java.io.Serializable


class GoalScorerData(var data: ArrayList<GoalScorer>) : Serializable