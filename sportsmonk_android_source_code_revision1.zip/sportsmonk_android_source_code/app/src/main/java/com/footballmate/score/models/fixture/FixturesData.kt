package com.footballmate.score.models.fixture

import java.io.Serializable

class FixturesData(val data: ArrayList<Fixture>) : Serializable
