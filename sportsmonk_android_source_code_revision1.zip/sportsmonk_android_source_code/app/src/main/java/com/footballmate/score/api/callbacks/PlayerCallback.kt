package com.footballmate.score.api.callbacks

import com.footballmate.score.models.players.Player

class PlayerCallback(var data: Player)