package com.footballmate.score.ui.viewmodels

import androidx.lifecycle.ViewModel
import com.footballmate.score.repository.FixturesRepository

class FixturesViewModel(private val sourceRepository: FixturesRepository) : ViewModel() {
    fun getFavoritesMatches() = sourceRepository.favorites()
}