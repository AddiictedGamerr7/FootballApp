package com.footballmate.score.ui.teams.results

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.footballmate.score.R
import com.footballmate.score.api.BASE_URL
import com.footballmate.score.api.RetrofitAdapter
import com.footballmate.score.api.callbacks.TeamCallback
import com.footballmate.score.events.OnTeamFixturesLoaded
import com.footballmate.score.models.fixture.Fixture
import com.footballmate.score.ui.teams.TeamDetailActivity
import com.footballmate.score.utils.*
import kotlinx.android.synthetic.main.include_recyclerview_progressbar_layout.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response


class TeamResultsFragment : Fragment() {
    private lateinit var onTeamFixturesLoaded: OnTeamFixturesLoaded

    fun setOnTeamFixturesLoaded(onTeamFixturesLoaded: OnTeamFixturesLoaded) {
        this.onTeamFixturesLoaded = onTeamFixturesLoaded
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.include_recyclerview_progressbar_layout, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        onTeamFixturesLoaded = (activity as? OnTeamFixturesLoaded)!!
        fetchTeamDetailFromAPI((context as TeamDetailActivity).getTeam().id)
    }

    private fun fetchTeamDetailFromAPI(teamId: Long) {
        showLoadingProgress(baseNestedLayout)
        val callback = RetrofitAdapter.createAPI(BASE_URL).teamResultsById(teamId)
        callback.enqueue(viewLifecycleOwner, object : Callback<TeamCallback> {
            override fun onFailure(call: Call<TeamCallback>, t: Throwable) {
                if (baseNestedLayout != null) {
                    showMessageLayout(context!!.getString(R.string.error_generic_message), baseNestedLayout)
                }
            }

            override fun onResponse(call: Call<TeamCallback>, response: Response<TeamCallback>) {
                hideLoadingProgress(baseNestedLayout)
                if (response.isSuccessful) {
                    val allFixtures: ArrayList<Fixture> = arrayListOf()
                    allFixtures.addAll(response.body()!!.data.localResults.data)
                    allFixtures.addAll(response.body()!!.data.visitorResults.data)
                    onTeamFixturesLoaded.onFixtureLoaded(allFixtures[0], false)
                    displayFixturesLite(allFixtures, baseNestedLayout, context!!, teamId)
                } else {
                    showMessageLayout(context!!.getString(R.string.error_generic_message), baseNestedLayout)
                }
            }
        })
    }
}
