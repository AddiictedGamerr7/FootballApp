package com.footballmate.score.models.team.coach

import java.io.Serializable

class CoachData(val data: TeamCoach) : Serializable
