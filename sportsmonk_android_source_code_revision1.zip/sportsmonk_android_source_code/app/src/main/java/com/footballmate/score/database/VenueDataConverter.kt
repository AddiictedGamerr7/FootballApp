package com.footballmate.score.database

import androidx.room.TypeConverter
import com.footballmate.score.models.fixture.venue.VenueData
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken


class VenueDataConverter {
    @TypeConverter
    fun fromString(value: String): VenueData? {
        val listType = object : TypeToken<VenueData>() {}.type
        return Gson().fromJson<VenueData>(value, listType)
    }

    @TypeConverter
    fun fromObject(stringList: VenueData?): String {
        val gson = Gson()
        return gson.toJson(stringList)
    }
}