package com.footballmate.score.ui.fixture

import android.content.Context
import androidx.recyclerview.widget.RecyclerView
import com.footballmate.score.models.leagues.CustomLeague
import com.footballmate.score.utils.TranslatorUtil
import com.google.cloud.translate.Translate

class MatchAdapterBundle(
        val leagues: ArrayList<CustomLeague>,
        val context: Context,
        val shouldOpenTeamDetail: Boolean
) {
    var translator: Translate = TranslatorUtil.getTranslateService(context)!!
    var favoriteMatchesIds: Array<Long> = arrayOf()
    var recyclerView: RecyclerView? = null
}