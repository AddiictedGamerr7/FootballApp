package com.footballmate.score.models.fixture.lineup

import com.footballmate.score.models.players.Player
import java.io.Serializable


class PlayerData(var data: Player) : Serializable