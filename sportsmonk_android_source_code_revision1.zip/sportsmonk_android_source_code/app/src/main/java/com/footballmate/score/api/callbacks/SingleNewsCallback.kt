package com.footballmate.score.api.callbacks

import com.footballmate.score.models.News

class SingleNewsCallback(var article: News)