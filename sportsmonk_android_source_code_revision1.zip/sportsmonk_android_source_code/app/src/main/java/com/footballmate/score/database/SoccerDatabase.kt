package com.footballmate.score.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import androidx.sqlite.db.SupportSQLiteDatabase
import com.footballmate.score.database.converters.assistant.AssistantConverter
import com.footballmate.score.database.converters.card.CardDataConverter
import com.footballmate.score.database.converters.card.CardListConverter
import com.footballmate.score.database.converters.coach.CoachConverter
import com.footballmate.score.database.converters.color.ColorConverter
import com.footballmate.score.database.converters.color.TeamColorConverter
import com.footballmate.score.database.converters.country.CountryConverter
import com.footballmate.score.database.converters.country.CountryDataConverter
import com.footballmate.score.database.converters.formation.FormationConverter
import com.footballmate.score.database.converters.goal.GoalDataConverter
import com.footballmate.score.database.converters.goal.GoalListConverter
import com.footballmate.score.database.converters.league.*
import com.footballmate.score.database.converters.player.PlayerDataConverter
import com.footballmate.score.database.converters.round.RoundConverter
import com.footballmate.score.database.converters.round.RoundDataConverter
import com.footballmate.score.database.converters.season.SeasonDataConverter
import com.footballmate.score.database.converters.stage.StageConverter
import com.footballmate.score.database.converters.stage.StageDataConverter
import com.footballmate.score.database.converters.time.StartingTimeConverter
import com.footballmate.score.database.converters.time.TimeConverter
import com.footballmate.score.database.converters.weather.TemperatureConverter
import com.footballmate.score.database.converters.weather.WeatherReportConverter
import com.footballmate.score.database.daos.FavoritesDao
import com.footballmate.score.database.daos.FixturesDao
import com.footballmate.score.database.daos.LeagueDao
import com.footballmate.score.models.Favorite
import com.footballmate.score.models.competitions.Competition
import com.footballmate.score.models.fixture.Fixture

@Database(entities = [
    Favorite::class,
    Competition::class,
    Fixture::class
], version = 1, exportSchema = false)

@TypeConverters(
        WeatherReportConverter::class,
        TemperatureConverter::class,
        ColorConverter::class,
        CardListConverter::class,
        GoalListConverter::class,
        TeamColorConverter::class,
        FormationConverter::class,
        ScoreConverter::class,
        TimeConverter::class,
        StartingTimeConverter::class,
        CoachConverter::class,
        StandingConverter::class,
        AssistantConverter::class,
        TeamConverter::class,
        PlayerDataConverter::class,
        StatsDataConverter::class,
        SubstitutionDataConverter::class,
        GoalDataConverter::class,
        CardDataConverter::class,
        VenueDataConverter::class,
        LeagueConverter::class,
        SeasonDataConverter::class,
        RoundDataConverter::class,
        RoundConverter::class,
        CountryConverter::class,
        CountryDataConverter::class,
        StageConverter::class,
        StageDataConverter::class,
        CoverageConverter::class,
        CustomLeagueConverter::class,
        CustomLeagueDataConverter::class,
        LeagueDataConverter::class
)
abstract class SoccerDatabase : RoomDatabase() {

    abstract fun fixtureDao(): FixturesDao
    abstract fun leaguesDao(): LeagueDao
    abstract fun favoritesDao(): FavoritesDao

    companion object {
        @Volatile
        private var instance: SoccerDatabase? = null

        fun getInstance(context: Context): SoccerDatabase {
            return instance ?: synchronized(this) {
                instance ?: buildDatabase(context).also { instance = it }
            }
        }

        private fun buildDatabase(context: Context): SoccerDatabase {
            return Room.databaseBuilder(context, SoccerDatabase::class.java, "futaa")
                    .addCallback(object : RoomDatabase.Callback() {
                        override fun onCreate(db: SupportSQLiteDatabase) {
                            super.onCreate(db)
                            //val request = OneTimeWorkRequestBuilder<StudentsDatabaseWorker>().build()
                            //WorkManager.getInstance().enqueue(request)
                        }
                    })
                    //.fallbackToDestructiveMigration()
                    .build()
        }
    }
}