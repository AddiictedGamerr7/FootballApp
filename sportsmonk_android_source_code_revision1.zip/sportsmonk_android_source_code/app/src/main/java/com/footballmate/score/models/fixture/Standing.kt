package com.footballmate.score.models.fixture

import java.io.Serializable

class Standing(
    val localteam_position: Int,
    val visitorteam_position: Int
): Serializable