package com.footballmate.score.ui.season.matches


class SeasonUpcomingMatchesFragment() : SeasonMatchesBaseFragment() {
    override fun getMatchesType() = "upcoming"
}