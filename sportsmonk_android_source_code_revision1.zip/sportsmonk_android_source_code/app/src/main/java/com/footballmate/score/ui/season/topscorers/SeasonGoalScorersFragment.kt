package com.footballmate.score.ui.season.topscorers

import androidx.recyclerview.widget.LinearLayoutManager
import com.footballmate.score.models.seasons.topscorers.TopScorer
import com.footballmate.score.ui.topscorers.TopGoalScorerAdapter
import com.footballmate.score.utils.showMessageLayout
import kotlinx.android.synthetic.main.include_base_recyclerview_layout.*
import kotlinx.android.synthetic.main.include_recyclerview_progressbar_layout.*


class SeasonGoalScorersFragment() : SeasonTopScorersBaseFragment() {
    override fun displayTopScorers() {
        val topScorers = requireArguments().getSerializable("top_scorers") as TopScorer
        if (topScorers.goalscorers.data.size > 0) {
            val adapter = TopGoalScorerAdapter(topScorers.goalscorers.data, requireContext())
            baseRecyclerView.layoutManager = LinearLayoutManager(context)
            baseRecyclerView.adapter = adapter
        } else {
            showMessageLayout("No goal scorers at the moment", baseNestedLayout)
        }
    }
}