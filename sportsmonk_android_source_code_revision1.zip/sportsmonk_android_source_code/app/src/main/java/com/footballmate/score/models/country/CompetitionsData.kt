package com.footballmate.score.models.country

import com.footballmate.score.models.competitions.Competition
import java.io.Serializable

class CompetitionsData(var data: ArrayList<Competition>) : Serializable