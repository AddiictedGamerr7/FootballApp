package com.footballmate.score.api

enum class Status {
    SUCCESS,
    ERROR,
    LOADING
}
