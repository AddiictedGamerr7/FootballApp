package com.footballmate.score.models.fixture

import java.io.Serializable

data class LineupEnvelop(
    val home: Lineup,
    val away: Lineup
):Serializable