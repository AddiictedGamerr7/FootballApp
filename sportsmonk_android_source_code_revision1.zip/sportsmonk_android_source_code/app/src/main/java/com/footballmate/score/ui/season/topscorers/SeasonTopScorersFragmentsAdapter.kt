package com.footballmate.score.ui.season.topscorers

import android.os.Bundle
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentStatePagerAdapter
import com.footballmate.score.models.seasons.topscorers.TopScorer

class SeasonTopScorersFragmentsAdapter(
    fragmentManager: FragmentManager,
    private val topScorers: TopScorer
) : FragmentStatePagerAdapter(fragmentManager) {
    override fun getItem(position: Int): Fragment {
        val bundle = Bundle()
        bundle.putSerializable("top_scorers", topScorers)
        return when (position) {
            0 -> {
                val fragment = SeasonGoalScorersFragment()
                fragment.arguments = bundle
                fragment
            }
            1 -> {
                val fragment = SeasonAssistScorersFragment()
                fragment.arguments = bundle
                fragment
            }
            else -> {
                val fragment = SeasonCardScorersFragment()
                fragment.arguments = bundle
                fragment
            }
        }
    }

    override fun getCount() = 3

    override fun getPageTitle(position: Int): CharSequence? {
        return when (position) {
            0 -> "Goals"
            1 -> "Assists"
            else -> "Cards"
        }
    }

}