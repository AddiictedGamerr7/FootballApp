package com.footballmate.score.database.converters.card

import androidx.room.TypeConverter
import com.footballmate.score.models.fixture.cards.Card
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken


class CardListConverter {
    @TypeConverter
    fun fromString(value: String): ArrayList<Card>? {
        val listType = object : TypeToken<ArrayList<Card>>() {}.type
        return Gson().fromJson<ArrayList<Card>>(value, listType)
    }

    @TypeConverter
    fun fromObject(stringList: ArrayList<Card>?): String {
        val gson = Gson()
        return gson.toJson(stringList)
    }
}