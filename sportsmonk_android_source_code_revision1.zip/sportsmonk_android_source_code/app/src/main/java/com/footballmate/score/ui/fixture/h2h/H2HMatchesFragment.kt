package com.footballmate.score.ui.fixture.h2h

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.footballmate.score.R
import com.footballmate.score.api.BASE_URL
import com.footballmate.score.api.RetrofitAdapter
import com.footballmate.score.api.callbacks.MatchesCallback
import com.footballmate.score.models.fixture.Fixture
import com.footballmate.score.utils.*
import kotlinx.android.synthetic.main.include_ads_layout.*
import kotlinx.android.synthetic.main.include_base_recyclerview_layout.*
import kotlinx.android.synthetic.main.include_recyclerview_progressbar_layout.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class H2HMatchesFragment : Fragment(R.layout.include_recyclerview_progressbar_layout) {

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        loadData()
        loadMediumBannerAds(requireContext(), advertLayout)
    }

    private fun loadData() {
        val fixture = requireArguments().getSerializable("fixture") as Fixture
        showLoadingProgress(baseNestedLayout)
        val callback = RetrofitAdapter.createAPI(BASE_URL).getH2H(fixture.localteam_id, fixture.visitorteam_id)
        callback.enqueue(viewLifecycleOwner, object : Callback<MatchesCallback> {
            override fun onFailure(call: Call<MatchesCallback>, t: Throwable) {
                if (baseNestedLayout != null) {
                    showMessageLayout(requireContext().getString(R.string.no_data_message), baseNestedLayout)
                }
            }

            override fun onResponse(call: Call<MatchesCallback>, response: Response<MatchesCallback>) {
                if (baseNestedLayout != null) {
                    hideLoadingProgress(baseNestedLayout)
                    if (response.isSuccessful) {
                        if (response.body() != null) {
                            if (response.body()!!.data.isNotEmpty()) {
                                val adapter = H2HMatchesAdapter(response.body()!!.data, requireContext())
                                baseRecyclerView.layoutManager = LinearLayoutManager(requireContext())
                                baseRecyclerView.adapter = adapter
                                baseRecyclerView.isNestedScrollingEnabled = true
                            } else {
                                showMessageLayout("No H2H matches found", baseNestedLayout)
                            }
                        } else {
                            showMessageLayout(requireContext().getString(R.string.error_generic_message), baseNestedLayout)
                        }
                    } else {
                        showMessageLayout(requireContext().getString(R.string.error_generic_message), baseNestedLayout)
                    }
                }
            }
        })
    }
}