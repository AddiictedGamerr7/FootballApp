package com.footballmate.score.models.fixture.color

import java.io.Serializable

class TeamColor(
    val color: String? = null,
    val kit_colors: String? = null
): Serializable