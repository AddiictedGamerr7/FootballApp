package com.footballmate.score.api.callbacks

import com.footballmate.score.models.team.Team

class TeamsCallback(var data: ArrayList<Team>)