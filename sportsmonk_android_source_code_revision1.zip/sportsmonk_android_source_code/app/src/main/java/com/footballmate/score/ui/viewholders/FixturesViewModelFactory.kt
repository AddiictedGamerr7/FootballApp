package com.footballmate.score.ui.viewholders

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.footballmate.score.repository.FixturesRepository
import com.footballmate.score.ui.viewmodels.FixturesViewModel

class FixturesViewModelFactory(private val sourceRepository: FixturesRepository) : ViewModelProvider.NewInstanceFactory() {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>) = FixturesViewModel(sourceRepository) as T
}