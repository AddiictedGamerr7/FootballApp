package com.footballmate.score.api.callbacks

import com.footballmate.score.models.seasons.topscorers.TopScorer

class SeasonTopScorersCallback(var data: TopScorer)