package com.footballmate.score.models.fixture.color

import java.io.Serializable

class Color(
        val localteam: TeamColor,
        val visitorteam: TeamColor
) : Serializable