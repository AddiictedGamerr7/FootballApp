package com.footballmate.score.models.leagues

import java.io.Serializable

class LeagueData(var data: League): Serializable