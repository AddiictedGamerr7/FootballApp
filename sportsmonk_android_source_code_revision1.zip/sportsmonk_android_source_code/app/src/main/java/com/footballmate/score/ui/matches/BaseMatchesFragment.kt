package com.footballmate.score.ui.matches

import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import com.footballmate.score.R
import com.footballmate.score.api.BASE_URL
import com.footballmate.score.api.RetrofitAdapter
import com.footballmate.score.api.callbacks.MatchesCallback
import com.footballmate.score.models.fixture.Fixture
import com.footballmate.score.utils.*
import kotlinx.android.synthetic.main.include_base_recyclerview_layout.*
import kotlinx.android.synthetic.main.include_recyclerview_progressbar_layout.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response


class BaseMatchesFragment : Fragment(R.layout.include_recyclerview_progressbar_layout) {


    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        loadMatchesFromServer()
    }

    private fun loadMatchesFromServer() {
        val from = requireArguments().getString("from")!!
        val to = requireArguments().getString("to")!!
        showLoadingProgress(baseNestedLayout)
        val callback = RetrofitAdapter.createAPI(BASE_URL).fixturesBetweenDates(from, to)
        callback.enqueue(viewLifecycleOwner, object : Callback<MatchesCallback> {
            override fun onFailure(call: Call<MatchesCallback>, t: Throwable) {
                if (baseNestedLayout != null) {
                    hideLoadingProgress(baseNestedLayout)
                    showMessageLayout(context!!.getString(R.string.error_generic_message), baseNestedLayout)
                }
            }

            override fun onResponse(
                call: Call<MatchesCallback>,
                response: Response<MatchesCallback>
            ) {
                hideLoadingProgress(baseNestedLayout)
                if (response.isSuccessful) {
                    val matches = response.body()
                    if (matches != null) {
                        if (matches.data.isNotEmpty()) {
                            if (baseRecyclerView != null) {
                                val data = if (from == DateTimeUtil.getCustomDate(0)) {
                                    ArrayList(matches.data.filter {
                                        it.time.status != "FT" ||
                                                it.time.status != "HT" ||
                                                it.time.status != "LIVE"
                                    }.sortedByDescending { it.time.starting_at.timestamp })
                                } else {
                                    matches.data
                                }
                                displayFixtures(data, baseNestedLayout, context!!, false)
                            }
                        } else {
                            showMessageLayout("No favorite matches found", baseNestedLayout)
                        }
                    }
                } else {
                    showMessageLayout(context!!.getString(R.string.error_generic_message), baseNestedLayout)
                }
            }
        })
    }

}
