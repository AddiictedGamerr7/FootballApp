package com.footballmate.score.utils

import android.content.Context
import com.footballmate.score.AppExecutors
import com.footballmate.score.database.SoccerDatabase
import com.footballmate.score.repository.FixturesRepository
import com.footballmate.score.repository.LeaguesRepository
import com.footballmate.score.ui.viewholders.FixturesViewModelFactory
import com.footballmate.score.ui.viewholders.LeaguesViewModelFactory

object InjectorUtils {

    private fun getFixturesRepo(c: Context) = FixturesRepository.getInstance(AppExecutors(), SoccerDatabase.getInstance(c).fixtureDao())
    private fun getCompetitionsRepo(c: Context) = LeaguesRepository.getInstance(AppExecutors(), SoccerDatabase.getInstance(c).leaguesDao())

    fun provideFixturesViewModelFactory(context: Context) = FixturesViewModelFactory(getFixturesRepo(context))
    fun provideLeaguesViewModelFactory(context: Context) = LeaguesViewModelFactory(getCompetitionsRepo(context))

}