package com.footballmate.score.models.standing

import java.io.Serializable

class StandingData(
        val data: ArrayList<TeamStanding>
) : Serializable
