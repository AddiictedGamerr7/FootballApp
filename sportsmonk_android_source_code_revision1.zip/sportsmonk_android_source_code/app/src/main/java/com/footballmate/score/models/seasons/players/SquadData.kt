package com.footballmate.score.models.seasons.players

import java.io.Serializable


class SquadData(var data: ArrayList<PlayerRanking>) : Serializable