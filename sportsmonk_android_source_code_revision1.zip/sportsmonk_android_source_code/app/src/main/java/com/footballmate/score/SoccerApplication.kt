package com.footballmate.score

import android.app.Application

class SoccerApplication : Application() {
    override fun onCreate() {
        super.onCreate()

    }
}