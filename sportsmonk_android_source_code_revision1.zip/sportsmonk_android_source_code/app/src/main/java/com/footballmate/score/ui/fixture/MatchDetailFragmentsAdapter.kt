package com.footballmate.score.ui.fixture

import android.os.Bundle
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentStatePagerAdapter
import com.footballmate.score.ui.fixture.h2h.H2HFragment
import com.footballmate.score.ui.fixture.lineup.LineupsFragment
import com.footballmate.score.ui.fixture.predictions.MatchPredictionsFragment
import com.footballmate.score.ui.fixture.timeline.MatchOverviewFragment
import com.footballmate.score.ui.standings.LeagueStandingsFragment

class MatchDetailFragmentsAdapter(
    fragmentManager: FragmentManager,
    private val seasonId: Long,
    private val homeTeamId: Long,
    private val awayTeamId: Long
) : FragmentStatePagerAdapter(fragmentManager) {
    override fun getItem(position: Int): Fragment {
        return when (position) {
            0 -> MatchOverviewFragment()
            1 -> LineupsFragment()
            2 -> H2HFragment()
            3 -> MatchPredictionsFragment()
            else -> {
                val bundle = Bundle()
                bundle.putLong("season_id", seasonId)
                bundle.putLong("home_id", homeTeamId)
                bundle.putLong("away_id", awayTeamId)
                val fragment = LeagueStandingsFragment()
                fragment.arguments = bundle
                fragment
            }
        }
    }

    override fun getCount() = 5

    override fun getPageTitle(position: Int): CharSequence? {
        return when (position) {
            0 -> "Timeline"
            1 -> "Lineup"
            2 -> "Matches"
            3 -> "Predictions"
            else -> "Standings"
        }
    }

}