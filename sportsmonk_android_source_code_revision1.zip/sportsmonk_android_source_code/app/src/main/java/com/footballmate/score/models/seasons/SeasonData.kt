package com.footballmate.score.models.seasons

import java.io.Serializable

class SeasonData(var data: Season) : Serializable