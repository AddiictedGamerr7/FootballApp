package com.footballmate.score.utils

import android.content.Context
import android.view.View
import android.widget.LinearLayout


object FacebookAdsUtil {
    val TAG = FacebookAdsUtil::class.java.simpleName

    fun loadFacebookInterstialAd(context: Context) {

//        interstitialAd.setAdListener(object : InterstitialAdListener {
//            override fun onInterstitialDisplayed(ad: Ad?) {
//                Log.d(TAG, "interstitialAd onInterstitialDisplayed ")
//            }
//
//            override fun onAdClicked(ad: Ad?) {
//                Log.d(TAG, "interstitialAd onAdClicked ")
//            }
//
//            override fun onInterstitialDismissed(ad: Ad?) {
//                Log.d(TAG, "interstitialAd onInterstitialDismissed ")
//
//            }
//
//            override fun onError(ad: Ad?, error: AdError?) {
//                Log.e(TAG, "interstitialAd failed to load: " + error!!.errorMessage)
//            }
//
//            override fun onAdLoaded(ad: Ad?) {
//                interstitialAd.show()
//            }
//
//            override fun onLoggingImpression(ad: Ad?) {
//            }
//
//        })
//
//        interstitialAd.loadAd()

    }

    fun loadFacebookBannerAd(context: Context, linearLayout: LinearLayout) {
//        adView.setAdListener(object : AdListener {
//            override fun onAdClicked(ad: Ad?) {
//                Log.d(TAG, "loadFacebookBannerAd: onAdClicked")
//            }
//
//            override fun onError(ad: Ad?, error: AdError?) {
//                Log.d(TAG, "loadFacebookBannerAd: onError: " + error!!.errorMessage)
//            }
//
//            override fun onAdLoaded(ad: Ad?) {
//                Log.d(TAG, "loadFacebookBannerAd: onAdLoaded")
//            }
//
//            override fun onLoggingImpression(ad: Ad?) {
//                Log.d(TAG, "loadFacebookBannerAd: onLoggingImpression")
//            }
//        })
//
//        adView.loadAd()
    }

    fun loadFacebookNativeAd(context: Context, view: View) {

//        nativeAd.setAdListener(object : NativeAdListener {
//            override fun onMediaDownloaded(ad: Ad) {
//                // Native ad finished downloading all assets
//                Log.e(TAG, "Native ad finished downloading all assets.")
//            }
//
//            override fun onError(ad: Ad, adError: AdError) {
//                // Native ad failed to load
//                Log.e(TAG, "Native ad failed to load: " + adError.errorMessage)
//            }
//
//            override fun onAdLoaded(ad: Ad) {
//                //ad.loadAd()
//                if (nativeAd == null || nativeAd != ad) {
//                    Log.d(TAG, "nativeAd == null || nativeAd != ad")
//                } else {
//                    Log.d(TAG, "inflateAd(nativeAd, context, view)")
//                    inflateAd(nativeAd, context, view)
//
//                }
//                // Native ad is loaded and ready to be displayed
//                Log.d(TAG, "Native ad is loaded and ready to be displayed!")
//            }
//
//            override fun onAdClicked(ad: Ad) {
//                // Native ad clicked
//                Log.d(TAG, "Native ad clicked!")
//            }
//
//            override fun onLoggingImpression(ad: Ad) {
//                // Native ad impression
//                Log.d(TAG, "Native ad impression logged!")
//            }
//        })

        // Request an ad
    }

}