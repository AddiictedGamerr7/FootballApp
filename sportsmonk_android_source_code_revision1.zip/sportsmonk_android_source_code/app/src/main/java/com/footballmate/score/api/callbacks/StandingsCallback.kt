package com.footballmate.score.api.callbacks

import com.footballmate.score.models.standing.Standing

class StandingsCallback(var data: ArrayList<Standing>)