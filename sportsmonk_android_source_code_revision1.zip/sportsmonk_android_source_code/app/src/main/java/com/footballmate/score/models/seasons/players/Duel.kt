package com.footballmate.score.models.seasons.players


class Duel(
        val total: Int? = null,
        val won: Int? = null
)