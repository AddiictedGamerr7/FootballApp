package com.footballmate.score.models.fixture.lineup

import java.io.Serializable


class PlayersData(var data: ArrayList<Player>): Serializable