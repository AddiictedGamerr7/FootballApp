package com.footballmate.score.utils

import android.widget.ImageView
import android.widget.Toast
import com.footballmate.score.AppExecutors
import com.footballmate.score.R
import com.footballmate.score.database.SoccerDatabase
import com.footballmate.score.models.Favorite
import com.footballmate.score.models.fixture.Fixture
import com.footballmate.score.ui.fixture.MatchAdapterBundle

object FavoriteUtil {
    fun addMatchToFavorites(fixture: Fixture, matchAdapterBundle: MatchAdapterBundle, imageView: ImageView) {
        AppExecutors().diskIO().execute {
            val favoritesDao = SoccerDatabase.getInstance(matchAdapterBundle.context).favoritesDao()
            val fxturesDao = SoccerDatabase.getInstance(matchAdapterBundle.context).fixtureDao()
            if (matchAdapterBundle.favoriteMatchesIds.contains(fixture.id)) {
                favoritesDao.removeMatchFromFavorites(fixture.id)
                fxturesDao.removeMatchFromFavorites(fixture.id)
                AppExecutors().mainThread().execute {
                    imageView.setImageResource(R.drawable.ic_star_outline_grey600_24dp)
//                    val fragmentManager = (matchAdapterBundle.context as MainActivity).supportFragmentManager
//                    val fragment = fragmentManager.findFragmentByTag("three") as FavoriteMatchesFragment
//                    fragmentManager.beginTransaction().detach(fragment).attach(fragment).commit()
                }
            } else {
                favoritesDao.insert(Favorite(fixture.id))
                fxturesDao.insert(fixture)
                AppExecutors().mainThread().execute {
                    Toast.makeText(matchAdapterBundle.context, "Match added to favorites", Toast.LENGTH_LONG).show()
                    imageView.setImageResource(R.drawable.ic_star_grey600_24dp)
                }
            }
        }
    }
}