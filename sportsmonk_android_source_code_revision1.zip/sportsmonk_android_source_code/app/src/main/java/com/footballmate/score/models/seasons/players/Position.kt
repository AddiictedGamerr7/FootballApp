package com.footballmate.score.models.seasons.players


class Position(
        val id: Long,
        val name: String
)