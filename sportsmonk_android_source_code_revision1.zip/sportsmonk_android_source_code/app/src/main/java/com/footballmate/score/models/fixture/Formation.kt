package com.footballmate.score.models.fixture

import java.io.Serializable

class Formation(
        val localteam_formation: String,
        val visitorteam_formation: String
) : Serializable