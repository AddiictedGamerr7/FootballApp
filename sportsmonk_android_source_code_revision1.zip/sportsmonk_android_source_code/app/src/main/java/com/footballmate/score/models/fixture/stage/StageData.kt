package com.footballmate.score.models.fixture.stage

import java.io.Serializable


class StageData(var data: Stage) : Serializable