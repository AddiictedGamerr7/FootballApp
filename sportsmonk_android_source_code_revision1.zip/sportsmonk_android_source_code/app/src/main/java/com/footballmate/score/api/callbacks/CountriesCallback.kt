package com.footballmate.score.api.callbacks

import com.footballmate.score.models.country.Country

class CountriesCallback(var data: ArrayList<Country>)