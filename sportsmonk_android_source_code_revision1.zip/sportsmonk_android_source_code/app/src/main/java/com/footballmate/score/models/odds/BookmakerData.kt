package com.footballmate.score.models.odds

data class BookmakerData(var data: List<Bookmaker>)