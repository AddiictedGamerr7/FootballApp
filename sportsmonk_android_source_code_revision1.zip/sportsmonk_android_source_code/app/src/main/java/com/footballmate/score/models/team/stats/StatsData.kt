package com.footballmate.score.models.team.stats

import java.io.Serializable

class StatsData(val data: Stats) : Serializable
