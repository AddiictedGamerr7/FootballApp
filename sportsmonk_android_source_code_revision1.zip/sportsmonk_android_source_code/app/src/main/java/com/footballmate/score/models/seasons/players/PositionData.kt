package com.footballmate.score.models.seasons.players

class PositionData(var data: Position)