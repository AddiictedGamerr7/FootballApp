package com.footballmate.score.models.seasons.players


class Foul(
        val committed: Int? = null,
        val drawn: Int? = null
)