package com.footballmate.score.models.team.stats


class ScoreStats(
        val total: Int,
        val home: Int,
        val away: Int
)