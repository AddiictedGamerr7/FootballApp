package com.footballmate.score.ui.standings

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.footballmate.score.R
import com.footballmate.score.api.BASE_URL
import com.footballmate.score.api.RetrofitAdapter
import com.footballmate.score.api.callbacks.StandingsCallback
import com.footballmate.score.utils.enqueue
import com.footballmate.score.utils.hideLoadingProgress
import com.footballmate.score.utils.showLoadingProgress
import com.footballmate.score.utils.showMessageLayout
import kotlinx.android.synthetic.main.include_base_recyclerview_layout.*
import kotlinx.android.synthetic.main.include_recyclerview_progressbar_layout.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response


class LeagueStandingsFragment() : Fragment() {

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.fragment_standings, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        loadCompetitions()
    }


    private fun loadCompetitions() {
        val seasonId = arguments!!.getLong("season_id")
        val homeId = arguments!!.getLong("home_id")
        val awayId = arguments!!.getLong("away_id")
        showLoadingProgress(baseNestedLayout)
        val call = RetrofitAdapter.createAPI(BASE_URL).standings(seasonId)
        call.enqueue(viewLifecycleOwner, object : Callback<StandingsCallback> {
            override fun onFailure(call: Call<StandingsCallback>, t: Throwable) {
                if (baseNestedLayout != null) {
                    showMessageLayout(context!!.getString(R.string.error_generic_message), baseNestedLayout)
                }
            }

            override fun onResponse(call: Call<StandingsCallback>, response: Response<StandingsCallback>) {
                hideLoadingProgress(baseNestedLayout)
                if (response.isSuccessful) {
                    if (response.body()!!.data.size > 0) {
                        if (baseRecyclerView != null) {
                            val adapter = StandingsAdapter(response.body()!!.data, context!!, homeId, awayId)
                            baseRecyclerView.layoutManager = LinearLayoutManager(context)
                            baseRecyclerView.adapter = adapter
                        }
                    } else {
                        showMessageLayout("Standings data not available", baseNestedLayout)
                    }
                } else {
                    showMessageLayout(context!!.getString(R.string.error_generic_message), baseNestedLayout)
                }
            }
        })
    }


}