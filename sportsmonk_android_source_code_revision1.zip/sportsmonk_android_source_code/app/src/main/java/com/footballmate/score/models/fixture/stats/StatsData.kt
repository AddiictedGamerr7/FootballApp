package com.footballmate.score.models.fixture.stats

import com.footballmate.score.models.fixture.substitution.Substitution
import java.io.Serializable

class StatsData(var data: ArrayList<Substitution>): Serializable