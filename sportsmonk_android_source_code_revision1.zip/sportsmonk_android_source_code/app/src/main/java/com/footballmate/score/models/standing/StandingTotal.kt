package com.footballmate.score.models.standing

import java.io.Serializable

class StandingTotal(
        val goal_difference: String,
        val points: Int
) : Serializable
