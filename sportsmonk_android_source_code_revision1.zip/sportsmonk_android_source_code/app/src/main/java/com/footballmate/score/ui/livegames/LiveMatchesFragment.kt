package com.footballmate.score.ui.livegames

import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import com.footballmate.score.AppExecutors
import com.footballmate.score.R
import com.footballmate.score.database.SoccerDatabase
import com.footballmate.score.utils.displayFixtures
import com.footballmate.score.utils.loadMediumBannerAds
import com.footballmate.score.utils.showMessageLayout
import kotlinx.android.synthetic.main.include_ads_layout.*
import kotlinx.android.synthetic.main.include_base_recyclerview_layout.*
import kotlinx.android.synthetic.main.include_recyclerview_progressbar_layout.*
import java.util.*
import kotlin.collections.ArrayList


class LiveMatchesFragment : Fragment(R.layout.include_recyclerview_progressbar_layout) {

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        Timer().scheduleAtFixedRate(object : TimerTask() {
            override fun run() {
                loadLiveMatchesFromDb()
            }
        }, 0, 1000 * 30)

        loadMediumBannerAds(requireContext(), advertLayout)
    }

    private fun loadLiveMatchesFromDb() {
        AppExecutors().diskIO().execute {
            if (context != null) {
                val dbInstance = SoccerDatabase.getInstance(requireContext())
                val liveMatches = dbInstance.fixtureDao().getLiveMatches()
                AppExecutors().mainThread().execute {
                    val onlyLiveMatches =
                        liveMatches.filter { it.time.status == "LIVE" || it.time.status == "HT" }
                            .sortedBy { it.time.starting_at.timestamp }
                    if (onlyLiveMatches.isNotEmpty()) {
                        displayFixtures(ArrayList(onlyLiveMatches), baseRecyclerView, requireContext(), false)
                    } else {
                        showMessageLayout("No live matches at the moment", baseNestedLayout)
                    }
                }
            }
        }
    }

}