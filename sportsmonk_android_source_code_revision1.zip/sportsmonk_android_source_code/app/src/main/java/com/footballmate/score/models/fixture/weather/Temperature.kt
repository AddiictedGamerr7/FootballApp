package com.footballmate.score.models.fixture.weather

import java.io.Serializable

class Temperature(
    val temp: Double,
    val unit: String
): Serializable