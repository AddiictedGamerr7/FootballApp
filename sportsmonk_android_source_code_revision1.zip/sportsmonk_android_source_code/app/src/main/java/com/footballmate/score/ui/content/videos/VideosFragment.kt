package com.footballmate.score.ui.content.videos

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.footballmate.score.R
import com.footballmate.score.api.RetrofitAdapter
import com.footballmate.score.api.VIDEO_URL
import com.footballmate.score.models.video.VideoHighlight
import com.footballmate.score.utils.hideLoadingProgress
import com.footballmate.score.utils.showLoadingProgress
import com.footballmate.score.utils.showMessageLayout
import kotlinx.android.synthetic.main.include_base_recyclerview_layout.*
import kotlinx.android.synthetic.main.include_recyclerview_progressbar_layout.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class VideosFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.include_recyclerview_progressbar_layout, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        loadGames()

        //.setOnRefreshListener { loadGames() }
    }

    private fun loadGames() {
        showLoadingProgress(baseNestedLayout)
        val callback = RetrofitAdapter.createAPI(VIDEO_URL).videos()
        callback.enqueue(object : Callback<ArrayList<VideoHighlight>> {
            override fun onFailure(call: Call<ArrayList<VideoHighlight>>, t: Throwable) {
                hideLoadingProgress(baseNestedLayout)
                if (context != null) {
                    showMessageLayout(
                        requireContext().getString(R.string.error_generic_message),
                        baseNestedLayout
                    )
                }
            }

            override fun onResponse(
                call: Call<ArrayList<VideoHighlight>>,
                response: Response<ArrayList<VideoHighlight>>
            ) {
                hideLoadingProgress(baseNestedLayout)
                if (response.isSuccessful) {
                    val adapter = VideosAdapter(response.body()!!, context!!)
                    baseRecyclerView.layoutManager = LinearLayoutManager(context)
                    baseRecyclerView.adapter = adapter
                } else {
                    showMessageLayout(
                        context!!.getString(R.string.error_generic_message),
                        baseNestedLayout
                    )
                }
            }
        })
    }

}