package com.footballmate.score.models.fixture.weather

import java.io.Serializable

class Wind(
    val speed: String,
    val degree: Int
): Serializable