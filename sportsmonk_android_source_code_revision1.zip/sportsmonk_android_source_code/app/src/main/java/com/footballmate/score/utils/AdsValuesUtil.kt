package com.footballmate.score.utils

const val facebookBannerPlacementId = "1286090798242535_1286104324907849"
const val facebookInterstialPlacementId = "1286090798242535_1286117114906570"
const val facebookNativePlacementId = "1286090798242535_1286121328239482"

const val admobAdId = "ca-app-pub-4076399697053521~3943319488"
const val admobBannerId = "ca-app-pub-4076399697053521/4425716971"
const val admobInterstialId = "ca-app-pub-4076399697053521/1872184754"
const val admobNativeId = "ca-app-pub-4076399697053521/7184221185"


const val startAppId = "211658867"