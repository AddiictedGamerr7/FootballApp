package com.footballmate.score.database.daos

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Query
import com.footballmate.score.models.competitions.Competition

@Dao
interface LeagueDao : BaseDao<Competition> {

    @Query("SELECT * FROM competitions")
    fun getLeagues(): LiveData<List<Competition>>

    @Query("SELECT * FROM favorite")
    fun getFavoriteMatchesIds(): Array<Long>

    @Query("DELETE FROM favorite WHERE id = :fixtureId")
    fun removeMatchFromFavorites(fixtureId: Long)
}