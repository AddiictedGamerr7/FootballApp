package com.footballmate.score.models.seasons.players


class Pass(
        val total: Int? = null,
        val accuracy: Int? = null,
        val key_passes: Int? = null
)