package com.footballmate.score.api.callbacks

import com.footballmate.score.models.seasons.SeasonUpcoming

class SeasonUpcomingCallback(var data: SeasonUpcoming)