package com.footballmate.score.ui.fixture

import android.os.Build
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.footballmate.score.AppExecutors
import com.footballmate.score.R
import com.footballmate.score.api.BASE_URL
import com.footballmate.score.api.RetrofitAdapter
import com.footballmate.score.api.callbacks.MatchCallback
import com.footballmate.score.database.SoccerDatabase
import com.footballmate.score.models.fixture.Fixture
import com.footballmate.score.utils.*
import com.google.android.material.tabs.TabLayout
import kotlinx.android.synthetic.main.activity_match_detail.*
import kotlinx.android.synthetic.main.include_match_layout.*
import kotlinx.android.synthetic.main.include_viewpager_tab_layout.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.util.*


class MatchDetailActivity : AppCompatActivity() {

    private var fixture: Fixture? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            window.navigationBarColor = ContextCompat.getColor(this, R.color.primary)
        }
        setContentView(R.layout.activity_match_detail)

        val match = intent.getSerializableExtra("match") as Fixture
        fetchMatchDetailFromAPI(match.id)

        val matchAdapterBundle = MatchAdapterBundle(arrayListOf(), this, true)
        MatchUtil.initializeMatch(match, fixtureLayout, matchAdapterBundle)


        setSupportActionBar(toolbar)
        supportActionBar!!.setDisplayHomeAsUpEnabled(true)
        loadInterstialAds(this)

        Timer().scheduleAtFixedRate(object : TimerTask() {
            override fun run() {
                loadLiveMatchesFromDb(match.id)
            }
        }, 0, 1000 * 15)

    }

    private fun loadLiveMatchesFromDb(matchId: Long) {
        AppExecutors().diskIO().execute {
            val dbInstance = SoccerDatabase.getInstance(this)
            val fixture = dbInstance.fixtureDao().getLiveMatchById(matchId)
            if (fixture != null) {
                AppExecutors().mainThread().execute {
                    val matchAdapterBundle = MatchAdapterBundle(arrayListOf(), this, true)
                    MatchUtil.initializeMatch(fixture, fixtureLayout, matchAdapterBundle)
                }
            }
        }
    }

    fun getMatchObject() = fixture

    private fun fetchMatchDetailFromAPI(fixtureId: Long) {
        showLoadingProgress(matchLayout)
        val callback = RetrofitAdapter.createAPI(BASE_URL).fixturesById(fixtureId)
        callback.enqueue(object : Callback<MatchCallback> {
            override fun onFailure(call: Call<MatchCallback>, t: Throwable) {
                showMessageLayout(getString(R.string.error_generic_message), matchLayout)
            }

            override fun onResponse(call: Call<MatchCallback>, response: Response<MatchCallback>) {
                hideLoadingProgress(matchLayout)
                if (response.isSuccessful) {
                    fixture = response.body()!!.data
                    supportActionBar!!.title = fixture!!.league!!.data.country.data.name + "::" + fixture!!.league!!.data.name

                    viewpager.adapter = MatchDetailFragmentsAdapter(supportFragmentManager, fixture!!.season_id, fixture!!.localteam_id, fixture!!.visitorteam_id)
                    tabLayout.setupWithViewPager(viewpager)
                    viewpager.offscreenPageLimit = 3
                    val scale = resources.displayMetrics.density
                    tabLayout.layoutParams.height = (36 * scale + 0.5F).toInt()
                    tabLayout.requestLayout()
                    tabLayout.tabMode = TabLayout.MODE_SCROLLABLE

                } else {
                    showMessageLayout(getString(R.string.error_generic_message), matchLayout)
                }
            }
        })
    }

}
