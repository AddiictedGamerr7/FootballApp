package com.footballmate.score.models.team.stats

import java.io.Serializable

class ScoringMinsData(val period: ArrayList<ScoringMinutes>) : Serializable
