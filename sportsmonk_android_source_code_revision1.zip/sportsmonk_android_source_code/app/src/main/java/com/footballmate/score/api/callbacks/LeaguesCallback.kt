package com.footballmate.score.api.callbacks

import com.footballmate.score.models.leagues.League

class LeaguesCallback(var data: ArrayList<League>)