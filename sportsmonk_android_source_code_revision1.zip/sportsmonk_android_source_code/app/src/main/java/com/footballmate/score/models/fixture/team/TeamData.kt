package com.footballmate.score.models.fixture.team

import com.footballmate.score.models.team.Team
import java.io.Serializable

class TeamData(var data: Team): Serializable