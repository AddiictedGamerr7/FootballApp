package com.footballmate.score.models.competitions

import java.io.Serializable

class CompetitionData(var data: Competition) : Serializable