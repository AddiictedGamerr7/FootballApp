package com.footballmate.score.models.seasons.players


class Dribble(
        val attempts: Int? = null,
        val success: Int? = null,
        val dribbled_past: Int? = null
)