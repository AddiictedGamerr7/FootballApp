package com.footballmate.score.models.odds

data class OddValuesData(var data: List<OddValues>)