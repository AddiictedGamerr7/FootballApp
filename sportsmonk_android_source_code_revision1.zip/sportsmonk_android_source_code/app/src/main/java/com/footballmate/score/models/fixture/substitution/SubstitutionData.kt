package com.footballmate.score.models.fixture.substitution

import java.io.Serializable

class SubstitutionData(var data: ArrayList<Substitution>): Serializable