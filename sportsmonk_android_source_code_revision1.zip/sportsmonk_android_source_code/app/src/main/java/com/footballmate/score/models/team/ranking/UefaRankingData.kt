package com.footballmate.score.models.team.ranking

import java.io.Serializable

class UefaRankingData(val data: UefaRanking) : Serializable
