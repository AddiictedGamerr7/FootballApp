package com.footballmate.score.models.leagues

import java.io.Serializable

class CustomLeagueData(var data: CustomLeague): Serializable