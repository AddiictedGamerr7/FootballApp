package com.footballmate.score.utils

import java.util.*

const val whatsappContact = "+254728110017"
const val facebookLink = "https://web.facebook.com/ronolikeaaron"
const val twitterLink = "http://twitter.com/Aroniez"

fun getCleanedTeamName(dirtyName: String): String {
    return dirtyName
        .lowercase(Locale.getDefault())
        .replace(" ", "_")
        .replace("#", "_")
        .replace(".", "_")
        .replace("$", "_")
        .replace("[", "_")
        .replace("]", "_")
}