package com.footballmate.score.utils

import android.content.Context
import android.widget.LinearLayout


object StartAppAdsUtil {

    fun showNativeAds(context: Context, linearLayout: LinearLayout) {


    }

    fun showBannerAds(context: Context, linearLayout: LinearLayout) {


    }

    fun showInterstialAds(context: Context) {

    }
}