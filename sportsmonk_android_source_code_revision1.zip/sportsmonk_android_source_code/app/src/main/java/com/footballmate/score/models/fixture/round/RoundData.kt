package com.footballmate.score.models.fixture.round

import java.io.Serializable


class RoundData(var data: Round) : Serializable