package com.footballmate.score.database.converters.goal

import androidx.room.TypeConverter
import com.footballmate.score.models.fixture.goals.Goal
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken


class GoalListConverter {
    @TypeConverter
    fun fromString(value: String): ArrayList<Goal>? {
        val listType = object : TypeToken<ArrayList<Goal>>() {}.type
        return Gson().fromJson<ArrayList<Goal>>(value, listType)
    }

    @TypeConverter
    fun fromObject(stringList: ArrayList<Goal>?): String {
        val gson = Gson()
        return gson.toJson(stringList)
    }
}