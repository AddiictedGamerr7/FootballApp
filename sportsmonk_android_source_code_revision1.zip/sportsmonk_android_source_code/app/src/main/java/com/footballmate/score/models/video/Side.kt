package com.footballmate.score.models.video

import java.io.Serializable

data class Side(
        var name: String? = "",
        var url: String? = ""
):Serializable