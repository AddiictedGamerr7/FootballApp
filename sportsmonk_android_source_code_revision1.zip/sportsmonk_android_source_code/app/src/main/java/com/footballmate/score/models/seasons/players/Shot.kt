package com.footballmate.score.models.seasons.players


class Shot(
        val shots_total: Int? = null,
        val shots_on_target: Int? = null,
        val shots_off_target: Int? = null
)