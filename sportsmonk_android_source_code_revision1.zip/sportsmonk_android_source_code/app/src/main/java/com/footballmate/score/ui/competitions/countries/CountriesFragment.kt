package com.footballmate.score.ui.competitions.countries

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.footballmate.score.R
import com.footballmate.score.api.BASE_URL
import com.footballmate.score.api.RetrofitAdapter
import com.footballmate.score.api.callbacks.CountriesCallback
import com.footballmate.score.utils.hideLoadingProgress
import com.footballmate.score.utils.showLoadingProgress
import com.footballmate.score.utils.showMessageLayout
import kotlinx.android.synthetic.main.include_base_recyclerview_layout.*
import kotlinx.android.synthetic.main.include_recyclerview_progressbar_layout.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response


class CountriesFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.include_recyclerview_progressbar_layout, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        loadMatchesFromServer()
    }


    private fun loadMatchesFromServer() {
        showLoadingProgress(baseNestedLayout)
        val callback = RetrofitAdapter.createAPI(BASE_URL).countries()
        callback.enqueue(object : Callback<CountriesCallback> {
            override fun onFailure(call: Call<CountriesCallback>, t: Throwable) {
                hideLoadingProgress(baseNestedLayout)
                showMessageLayout(
                    context!!.getString(R.string.error_generic_message),
                    baseNestedLayout
                )
            }

            override fun onResponse(
                call: Call<CountriesCallback>,
                response: Response<CountriesCallback>
            ) {
                hideLoadingProgress(baseNestedLayout)
                if (response.isSuccessful) {
                    val matches = response.body()!!
                    if (matches.data.isNotEmpty()) {
                        if (context != null) {
                            val adapter = CountriesAdapter(matches.data, context!!)
                            baseRecyclerView.layoutManager = LinearLayoutManager(context)
                            baseRecyclerView.adapter = adapter
                        }
                    } else {
                        showMessageLayout("No countries found", baseNestedLayout)
                    }
                } else {
                    showMessageLayout(
                        context!!.getString(R.string.error_generic_message),
                        baseNestedLayout
                    )
                }
            }
        })
    }

}
