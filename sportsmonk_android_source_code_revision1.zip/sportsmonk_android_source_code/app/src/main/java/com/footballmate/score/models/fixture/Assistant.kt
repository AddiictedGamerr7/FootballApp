package com.footballmate.score.models.fixture

import java.io.Serializable

class Assistant(
    val first_assistant_id: Long,
    val home_fault: Long,
    val fourth_official_id: Long
): Serializable