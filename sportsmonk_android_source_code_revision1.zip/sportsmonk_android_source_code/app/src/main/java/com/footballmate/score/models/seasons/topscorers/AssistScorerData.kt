package com.footballmate.score.models.seasons.topscorers

import java.io.Serializable


class AssistScorerData(var data: ArrayList<AssistScorer>) : Serializable