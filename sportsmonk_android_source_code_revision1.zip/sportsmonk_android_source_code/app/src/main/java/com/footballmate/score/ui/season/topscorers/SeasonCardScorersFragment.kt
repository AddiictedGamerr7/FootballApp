package com.footballmate.score.ui.season.topscorers

import androidx.recyclerview.widget.LinearLayoutManager
import com.footballmate.score.models.seasons.topscorers.TopScorer
import com.footballmate.score.ui.topscorers.TopCardScorersAdapter
import com.footballmate.score.utils.showMessageLayout
import kotlinx.android.synthetic.main.include_base_recyclerview_layout.*
import kotlinx.android.synthetic.main.include_recyclerview_progressbar_layout.*


class SeasonCardScorersFragment() : SeasonTopScorersBaseFragment() {
    override fun displayTopScorers() {
        val topScorers = requireArguments().getSerializable("top_scorers") as TopScorer
        if (topScorers.cardscorers.data.size > 0) {
            val adapter = TopCardScorersAdapter(topScorers.cardscorers.data, requireContext())
            baseRecyclerView.layoutManager = LinearLayoutManager(context)
            baseRecyclerView.adapter = adapter
        } else {
            showMessageLayout("No card scorers at the moment", baseNestedLayout)
        }
    }

}