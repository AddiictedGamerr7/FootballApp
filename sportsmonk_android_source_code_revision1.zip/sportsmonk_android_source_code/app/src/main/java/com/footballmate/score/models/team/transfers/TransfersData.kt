package com.footballmate.score.models.team.transfers

import java.io.Serializable

class TransfersData(val data: ArrayList<Transfer>) : Serializable
