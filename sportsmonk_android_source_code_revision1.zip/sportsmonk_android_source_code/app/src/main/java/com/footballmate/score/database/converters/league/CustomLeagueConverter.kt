package com.footballmate.score.database.converters.league

import androidx.room.TypeConverter
import com.footballmate.score.models.leagues.CustomLeague
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken


class CustomLeagueConverter {
    @TypeConverter
    fun fromString(value: String): CustomLeague? {
        val listType = object : TypeToken<CustomLeague>() {}.type
        return Gson().fromJson<CustomLeague>(value, listType)
    }

    @TypeConverter
    fun fromObject(stringList: CustomLeague?): String {
        val gson = Gson()
        return gson.toJson(stringList)
    }
}