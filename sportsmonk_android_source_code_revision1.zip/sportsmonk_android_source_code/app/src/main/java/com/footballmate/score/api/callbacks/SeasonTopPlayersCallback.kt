package com.footballmate.score.api.callbacks

import com.footballmate.score.models.seasons.players.PlayerRanking

class SeasonTopPlayersCallback(var data: PlayerRanking)