package com.footballmate.score.api.callbacks

import com.footballmate.score.models.leagues.League

class LeagueCallback(var data: League)