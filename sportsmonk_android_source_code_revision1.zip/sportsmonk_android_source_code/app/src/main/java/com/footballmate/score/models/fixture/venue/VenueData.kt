package com.footballmate.score.models.fixture.venue

import java.io.Serializable

class VenueData(var data: Venue): Serializable