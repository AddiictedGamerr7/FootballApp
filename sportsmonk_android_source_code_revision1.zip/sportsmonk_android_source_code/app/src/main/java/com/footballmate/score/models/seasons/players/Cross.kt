package com.footballmate.score.models.seasons.players


class Cross(
        val total: Int? = null,
        val accurate: Int? = null
)