package com.footballmate.score.repository

import androidx.lifecycle.LiveData
import com.footballmate.score.AppExecutors
import com.footballmate.score.api.BASE_URL
import com.footballmate.score.api.Resource
import com.footballmate.score.api.RetrofitAdapter
import com.footballmate.score.api.callbacks.CompetitionsCallback
import com.footballmate.score.database.daos.LeagueDao
import com.footballmate.score.models.competitions.Competition

class LeaguesRepository(
        private val appExecutors: AppExecutors,
        private val leagueDao: LeagueDao
) {

    fun competitions(): LiveData<Resource<List<Competition>>> {
        return object : NetworkBoundResource<List<Competition>, CompetitionsCallback>(appExecutors) {
            override fun saveCallResult(item: CompetitionsCallback) {
                leagueDao.insertAll(item.data)
            }

            override fun shouldFetch(data: List<Competition>?) = true

            override fun loadFromDb() = leagueDao.getLeagues()

            override fun createCall() = RetrofitAdapter.createAPI(BASE_URL).leaguesLiveData()
        }.asLiveData()
    }

    companion object {
        @Volatile
        private var instance: LeaguesRepository? = null

        fun getInstance(appExecutors: AppExecutors, competitionsDao: LeagueDao) =
                instance ?: synchronized(this) {
                    instance
                            ?: LeaguesRepository(appExecutors, competitionsDao).also { instance = it }
                }
    }
}
