package com.footballmate.score.models.fixture

import java.io.Serializable

data class Substitution(
    val time: String,
    val substitution: String
): Serializable