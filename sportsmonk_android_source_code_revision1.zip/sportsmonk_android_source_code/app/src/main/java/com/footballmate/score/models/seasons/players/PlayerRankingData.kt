package com.footballmate.score.models.seasons.players

import com.footballmate.score.models.players.Player
import java.io.Serializable


class PlayerRankingData(var data: Player): Serializable