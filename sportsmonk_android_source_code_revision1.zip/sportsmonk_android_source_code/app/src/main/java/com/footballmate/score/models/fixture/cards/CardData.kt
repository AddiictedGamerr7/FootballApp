package com.footballmate.score.models.fixture.cards

import java.io.Serializable

class CardData(var data: ArrayList<Card>): Serializable