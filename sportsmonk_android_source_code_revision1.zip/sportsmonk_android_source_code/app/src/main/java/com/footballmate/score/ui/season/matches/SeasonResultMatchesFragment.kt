package com.footballmate.score.ui.season.matches


class SeasonResultMatchesFragment : SeasonMatchesBaseFragment() {

    override fun getMatchesType() = "results"

}