package com.footballmate.score.models.seasons.topscorers

import java.io.Serializable


class CardScorerData(var data: ArrayList<CardScorer>) : Serializable