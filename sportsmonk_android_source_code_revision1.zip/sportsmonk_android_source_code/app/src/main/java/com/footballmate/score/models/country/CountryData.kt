package com.footballmate.score.models.country

import java.io.Serializable

class CountryData(var data: Country): Serializable