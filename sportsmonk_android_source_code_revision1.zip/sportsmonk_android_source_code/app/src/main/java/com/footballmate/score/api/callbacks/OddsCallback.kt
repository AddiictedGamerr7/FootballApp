package com.footballmate.score.api.callbacks

import com.footballmate.score.models.odds.Odd

class OddsCallback(var data: ArrayList<Odd>)